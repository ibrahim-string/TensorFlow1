All in one module to scrap: YOUTUBE, kaggle, imdb, AI-jobs.net, g2.com, vesselfiner.com, indeed.
This is module is only for research purpose. 